<template>
    <div>
        <hr/> 
        <footer> 
        
        </footer>
        <div><img src="../assets/logo03.png"></div>
   </div>  
  </template>

<script>
 export default {} 
 </script>
 <style scoped> 
footer{
    background:#4bbe09;
    padding: .5px;
}

div{
    text-align: right;
}</style>