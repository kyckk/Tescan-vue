<template>
    <header>
     
        <h5><b>인사 괸리</b></h5>
        
    </header>
    <hr/>
</template>
  
<script>
  export default {
  
  }
</script>
  
<style scoped>
  header {
    text-align: center;
    padding:25px;
    border-bottom: 1px solid #4bbe09;
    background:#f7f7f7;
}
</style>
